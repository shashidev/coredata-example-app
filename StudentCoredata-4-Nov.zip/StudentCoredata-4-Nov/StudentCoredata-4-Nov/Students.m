//
//  Students.m
//  StudentCoredata-4-Nov
//
//  Created by Kumar on 04/11/15.
//  Copyright (c) 2015 Kumar. All rights reserved.
//

#import "Students.h"


@implementation Students

@dynamic studentRollno;
@dynamic studentName;
@dynamic studentAddress;
@dynamic studenPhoneno;

@end
