//
//  Students.h
//  StudentCoredata-4-Nov
//
//  Created by Kumar on 04/11/15.
//  Copyright (c) 2015 Kumar. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Students : NSManagedObject

@property (nonatomic, retain) NSNumber * studentRollno;
@property (nonatomic, retain) NSString * studentName;
@property (nonatomic, retain) NSString * studentAddress;
@property (nonatomic, retain) NSNumber * studenPhoneno;

@end
