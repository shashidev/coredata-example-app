//
//  AddStudentViewController.h
//  StudentCoredata-4-Nov
//
//  Created by Kumar on 04/11/15.
//  Copyright (c) 2015 Kumar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddStudentViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *studentRollno;
@property (weak, nonatomic) IBOutlet UITextField *studentName;
@property (weak, nonatomic) IBOutlet UITextField *studentAddress;
@property (weak, nonatomic) IBOutlet UITextField *studentPhoneno;
- (IBAction)save:(id)sender;
-(void)myManagedObjectContex;
-(NSString *)DBpath;



@end
