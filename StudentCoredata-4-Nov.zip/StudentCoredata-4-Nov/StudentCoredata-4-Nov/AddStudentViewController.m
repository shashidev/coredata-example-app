//
//  AddStudentViewController.m
//  StudentCoredata-4-Nov
//
//  Created by Kumar on 04/11/15.
//  Copyright (c) 2015 Kumar. All rights reserved.
//

#import "AddStudentViewController.h"
#import "AppDelegate.h"
#import "Students.h"
#import "StudentTableViewController.h"

@interface AddStudentViewController ()

@end

@implementation AddStudentViewController

-(void)myManagedObjectContex
{
//    UIApplication *application=[UIApplication sharedApplication];
//    AppDelegate *mydelegate=(AppDelegate *)application.delegate;
//    NSManagedObjectContext *contex=mydelegate.managedObjectContext;

}
-(NSString *)DBpath
{
    NSArray *dir=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *dbpath=[NSString stringWithFormat:@"%@/studentdatabase.coredata",[dir lastObject]];
    NSLog(@"%@",dbpath);
    return dbpath;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In at storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)save:(id)sender {
    
//    NSArray *dir=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
//    NSString *dbpath=[NSString stringWithFormat:@"%@/studentdatabase.coredata",[dir lastObject]];
//    NSLog(@"%@",dbpath);
    [self DBpath];
    
    UIApplication *application=[UIApplication sharedApplication];
    AppDelegate *mydelegate=(AppDelegate *)application.delegate;
    NSManagedObjectContext *contex=mydelegate.managedObjectContext;
    
    Students *student=[NSEntityDescription insertNewObjectForEntityForName:@"Students" inManagedObjectContext:contex];
    
    student.studentRollno=[NSNumber numberWithInt:[_studentRollno.text intValue]];
    student.studentName=_studentName.text;
    student.studentAddress=_studentAddress.text;
    student.studenPhoneno=[NSNumber numberWithInt:[_studentPhoneno.text intValue]];
    [contex save:nil];
   NSLog(@"Data Inserted");
    
    
}
@end
