//
//  UpdateStudentViewController.h
//  StudentCoredata-4-Nov
//
//  Created by Kumar on 04/11/15.
//  Copyright (c) 2015 Kumar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UpdateStudentViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *findRollno;
@property (weak, nonatomic) IBOutlet UITextField *updateRollno;
@property (weak, nonatomic) IBOutlet UITextField *updateName;
@property (weak, nonatomic) IBOutlet UITextField *updateAddress;
@property (weak, nonatomic) IBOutlet UITextField *updatePhoneno;
- (IBAction)updateNow:(id)sender;
- (IBAction)find:(id)sender;
- (IBAction)displayStudents:(id)sender;
- (IBAction)deleteStudent:(id)sender;

-(NSManagedObjectContext *)managedContext;

@end
