//
//  StudentTableViewController.m
//  StudentCoredata-4-Nov
//
//  Created by Kumar on 04/11/15.
//  Copyright (c) 2015 Kumar. All rights reserved.
//

#import "StudentTableViewController.h"
#import "Students.h"

@interface StudentTableViewController ()

@end

@implementation StudentTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return _studentArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    Students *temp=[_studentArray objectAtIndex:indexPath.row];
    
//    cell.textLabel.text=[NSString stringWithFormat:@"%@",temp.studentAddress];
    cell.textLabel.text=temp.studentName;
//cell.textLabel.text=temp.studentAddress;
//    cell.textLabel.text=[NSString stringWithFormat:@"%@",temp.studenPhoneno];
//
    return cell;
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    [self.tableView reloadData];
}
@end
