//
//  UpdateStudentViewController.m
//  StudentCoredata-4-Nov
//
//  Created by Kumar on 04/11/15.
//  Copyright (c) 2015 Kumar. All rights reserved.
//

#import "UpdateStudentViewController.h"
#import "Students.h"
#import "AppDelegate.h"
#import "StudentTableViewController.h"

@interface UpdateStudentViewController ()

@end

@implementation UpdateStudentViewController

-(NSManagedObjectContext *)managedContext
{
    
    UIApplication *application=[UIApplication sharedApplication];
    AppDelegate *mydelegate=(AppDelegate *)application.delegate;
    NSManagedObjectContext *contex=mydelegate.managedObjectContext;
    return contex;

}



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}


- (IBAction)updateNow:(id)sender {
    
    
    NSNumber *found=[NSNumber numberWithInt:[_findRollno.text intValue]];
    
    NSFetchRequest *f=[NSFetchRequest fetchRequestWithEntityName:@"Students"];
    NSArray *result=[[self managedContext] executeFetchRequest:f error:nil];
    
    for(Students *temp in result)
    {
        if([found isEqualToNumber:temp.studentRollno])
        {
            temp.studentRollno=[NSNumber numberWithInt:[_updateRollno.text intValue]];
            temp.studentName=_updateName.text;
            temp.studentAddress=_updateAddress.text;
            temp.studenPhoneno=[NSNumber numberWithInt:[_updatePhoneno.text intValue]];
            
            NSLog(@"  %@  %@ ",temp.studentName,temp.studentAddress);

        }
    }

}

- (IBAction)find:(id)sender {
    
    UIApplication *application=[UIApplication sharedApplication];
    AppDelegate *mydelegate=(AppDelegate *)application.delegate;
    NSManagedObjectContext *contex=mydelegate.managedObjectContext;
    
    NSNumber *found=[NSNumber numberWithInt:[_findRollno.text intValue]];
    
    NSFetchRequest *f=[NSFetchRequest fetchRequestWithEntityName:@"Students"];
    NSArray *result=[contex executeFetchRequest:f error:nil];
    
    for(Students *temp in result)
    {
      if([found isEqualToNumber:temp.studentRollno])
      {
          _updateRollno.text=[NSString stringWithFormat:@"%@",temp.studentRollno];
          _updateName.text=temp.studentName;
          _updateAddress.text=temp.studentAddress;
          _updatePhoneno.text=[NSString stringWithFormat:@"%@",temp.studenPhoneno];
          
          
      }
    }
    
}

- (IBAction)displayStudents:(id)sender {
    
    
    NSFetchRequest *request=[NSFetchRequest fetchRequestWithEntityName:@"Students"];
    NSArray *result=[[self managedContext] executeFetchRequest:request error:nil];
    
    StudentTableViewController *s=[[StudentTableViewController alloc]init];
    s.studentArray=result;
    [self.navigationController pushViewController:s animated:YES];
    
    
}

- (IBAction)deleteStudent:(id)sender {
    
    
    NSNumber *found=[NSNumber numberWithInt:[_findRollno.text intValue]];
    NSFetchRequest *fetch=[NSFetchRequest fetchRequestWithEntityName:@"Students"];
    NSArray *result=[[self managedContext] executeFetchRequest:fetch error:nil];
    for(Students *temp in result)
    {
        if([found isEqualToNumber:temp.studentRollno])
        {
            _updateRollno.text=[NSString stringWithFormat:@"%@",temp.studentRollno];
            _updateName.text=temp.studentName;
            _updateAddress.text=temp.studentAddress;
            _updatePhoneno.text=[NSString stringWithFormat:@"%@",temp.studenPhoneno];
            
            [fetch setPredicate:[NSPredicate predicateWithFormat:@"studentRollno==%@ AND studentName==%@ AND studentAddress==%@ AND studentRollno==%@",_updateRollno.text,_updateName.text,_updateAddress.text,_updatePhoneno.text]];
            [[self managedContext] deleteObject:temp];
           
            
            _updateName.text=nil;
            _updateRollno.text=nil;
            _updateAddress.text=nil;
            _updatePhoneno.text=nil;
        }
    }
    [[self managedContext] save:nil];
    
}

@end
